package engines.physics;

public enum Direction {
    UP, DOWN, RIGHT, LEFT,
    UpRight, UpLeft, DownRight, DownLeft


}

