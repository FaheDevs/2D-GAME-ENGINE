package engines.physics;

public class PhysicsUtilities {

    public static final int SPEED = 64;
    public static final int LEFT = 0;
    public static final int RIGHT = 1;
    public static final int UP = 2;
    public static final int DOWN = 3;


}
