package Command;

import Kernel.Kernel;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyList extends Kernel implements KeyListener {


    @Override
    public void keyTyped(KeyEvent keyEvent) {

    }

    @Override
    public void keyPressed(KeyEvent keyEvent) {

    }

    @Override
    public void keyReleased(KeyEvent keyEvent) {

    }
}
